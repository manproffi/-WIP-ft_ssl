#!/bin/bash

FILE="../ft_ssl"

if [ -e $FILE ]; then
	mv $FILE .
fi

echo "pickle rick" | ./ft_ssl md5
echo "--------------"
echo "Do not pity the dead, Harry." | ./ft_ssl md5 -p
echo "--------------"
echo "Pity the living." | ./ft_ssl md5 -q -r
echo "--------------"
echo "And above all," > file
./ft_ssl md5 file
echo "--------------"
./ft_ssl md5 -r file
echo "--------------"
 ./ft_ssl md5 -s "pity those that aren't following baerista on spotify."
echo "--------------"
echo "be sure to handle edge cases carefully" | ./ft_ssl md5 -p file
echo "--------------"
echo "some of this will not make sense at first" | ./ft_ssl md5 file
echo "--------------"
echo "but eventually you will understand" | ./ft_ssl md5 -p -r file
echo "--------------"
echo "GL HF let's go" | ./ft_ssl md5 -p -s "foo" file
echo "--------------"
echo "one more thing" | ./ft_ssl md5 -r -p -s "foo" file -s "bar"
echo "--------------"
echo "just to be extra clear" | ./ft_ssl md5 -r -q -p -s "foo" file